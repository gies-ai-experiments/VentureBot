from pydantic import BaseModel

class MarketResponse(BaseModel):
    search_volume: int
    trend: str
    competition: str