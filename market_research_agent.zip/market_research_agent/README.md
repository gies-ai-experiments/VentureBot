# Market Research Agent

A lightweight FastAPI-based microservice that simulates market research for startup ideas. This project demonstrates modular Python design, API development, and mock data handling—perfect for showcasing skills in AI agent systems and backend architecture.

---

## Features

- FastAPI endpoint to research keyword trends
- Simulated mock data response for quick testing
- Modular code structure (agent logic, schema, API)
- Swagger UI auto-generated at `/docs`
- Designed for extension into a multi-agent system

---

## Project Structure

```
market_research_agent/
├── main.py           # FastAPI app
├── agent.py          # Core market insight logic
├── schema.py         # Response model (Pydantic)
├── requirements.txt  # Python dependencies
└── README.md         # Project documentation
```

---

## How to Run

### 1. Clone or Download the Repo

```bash
git clone <your-repo-url>
cd market_research_agent
```

### 2. Create & Activate Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the API

```bash
uvicorn main:app --reload
```

Visit: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

## Example Request

```http
GET /research?keyword=fitness
```

###  Response

```json
{
  "search_volume": 25000,
  "trend": "rising",
  "competition": "medium"
}
```

