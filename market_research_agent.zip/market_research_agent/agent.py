def fetch_market_insights(keyword: str) -> dict:
    mock_data = {
        "fitness": {"search_volume": 25000, "trend": "rising", "competition": "medium"},
        "ai": {"search_volume": 40000, "trend": "exploding", "competition": "high"},
        "crypto": {"search_volume": 15000, "trend": "declining", "competition": "high"},
    }

    return mock_data.get(keyword.lower(), {
        "search_volume": 5000,
        "trend": "unknown",
        "competition": "unknown"
    })