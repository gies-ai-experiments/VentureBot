from fastapi import FastAPI, Query
from agent import fetch_market_insights
from schema import MarketResponse

app = FastAPI(title="Market Research Agent")

@app.get("/research", response_model=MarketResponse)
def research(keyword: str = Query(..., min_length=2, max_length=50)):
    result = fetch_market_insights(keyword)
    return result